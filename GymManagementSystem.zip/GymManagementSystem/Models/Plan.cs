namespace GymManagementSystem.Models;

public class Plan
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public string Description { get; set; } = null!;
    public int DurationDays { get; set; }
    public decimal Price { get; set; }
    public bool IsActive { get; set; }

    public ICollection<MemberPlan> MemberPlans { get; set; } = new List<MemberPlan>();
}
