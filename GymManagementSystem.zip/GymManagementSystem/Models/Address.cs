using System.ComponentModel.DataAnnotations.Schema;

namespace GymManagementSystem.Models;

/// <summary>Owned value object: (Building #, Street, City).</summary>
public class Address
{
    public int BuildingNumber { get; set; }
    public string Street { get; set; } = null!;
    public string City { get; set; } = null!;

    [NotMapped]
    public string Full => $"{BuildingNumber}, {Street}, {City}";
}
