using System.ComponentModel.DataAnnotations.Schema;

namespace GymManagementSystem.Models;

/// <summary>Membership: the "Assigned to" relationship between Member and Plan (with StartDate / EndDate).</summary>
public class MemberPlan
{
    public int Id { get; set; }
    public int MemberId { get; set; }
    public int PlanId { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }

    public Member Member { get; set; } = null!;
    public Plan Plan { get; set; } = null!;

    /// <summary>Computed: "Active" if EndDate &gt; Now, else "Expired".</summary>
    [NotMapped]
    public string Status => EndDate > DateTime.Now ? "Active" : "Expired";

    [NotMapped]
    public bool IsActive => EndDate > DateTime.Now;
}
