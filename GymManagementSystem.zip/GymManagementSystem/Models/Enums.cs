namespace GymManagementSystem.Models;

public enum Gender { Male = 1, Female = 2 }

public enum Speciality { Strength = 1, Cardio, Yoga, Pilates, CrossFit, Boxing, Nutrition, Zumba }

public enum SessionCategory { Strength = 1, Cardio, Yoga, Pilates, CrossFit, Boxing, Zumba, Stretching }
