using System.ComponentModel.DataAnnotations.Schema;

namespace GymManagementSystem.Models;

public class Session
{
    public int Id { get; set; }
    public string Description { get; set; } = null!;
    public int Capacity { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public SessionCategory Category { get; set; }

    public int TrainerId { get; set; }
    public Trainer Trainer { get; set; } = null!;

    [NotMapped]
    public string Status => DateTime.Now >= EndDate ? "Finished" : DateTime.Now >= StartDate ? "Ongoing" : "Upcoming";
}
