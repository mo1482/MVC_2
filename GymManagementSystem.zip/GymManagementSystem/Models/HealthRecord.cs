namespace GymManagementSystem.Models;

/// <summary>One-to-one with Member (shared primary key). Backs MemberController.HealthRecordDetails.</summary>
public class HealthRecord
{
    public int Id { get; set; }              // PK + FK to Member
    public decimal HeightCm { get; set; }
    public decimal WeightKg { get; set; }
    public string BloodType { get; set; } = null!;
    public string? Note { get; set; }

    public Member Member { get; set; } = null!;
}
