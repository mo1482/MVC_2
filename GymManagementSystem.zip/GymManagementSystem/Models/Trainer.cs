namespace GymManagementSystem.Models;

public class Trainer
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string Phone { get; set; } = null!;
    public DateTime DateOfBirth { get; set; }
    public Gender Gender { get; set; }
    public Address Address { get; set; } = new();
    public DateTime HireDate { get; set; }
    public Speciality Speciality { get; set; }

    public ICollection<Session> Sessions { get; set; } = new List<Session>();
}
