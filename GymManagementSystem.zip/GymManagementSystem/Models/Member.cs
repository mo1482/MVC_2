namespace GymManagementSystem.Models;

public class Member
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string Phone { get; set; } = null!;
    public DateTime DateOfBirth { get; set; }
    public Gender Gender { get; set; }
    public Address Address { get; set; } = new();
    public DateTime JoinDate { get; set; }
    public string? Photo { get; set; }

    public HealthRecord? HealthRecord { get; set; }
    public ICollection<MemberPlan> MemberPlans { get; set; } = new List<MemberPlan>();
}
