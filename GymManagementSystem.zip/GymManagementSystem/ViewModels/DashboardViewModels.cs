namespace GymManagementSystem.ViewModels;

public class HomeViewModel
{
    public int TotalMembers { get; set; }
    public int TotalTrainers { get; set; }
    public int ActivePlans { get; set; }
    public int UpcomingSessions { get; set; }
}

public class ChartPoint
{
    public string Label { get; set; } = null!;
    public int Value { get; set; }
}

public class DashboardViewModel
{
    public int TotalMembers { get; set; }
    public int NewMembersThisMonth { get; set; }
    public int MaleMembers { get; set; }
    public int FemaleMembers { get; set; }
    public int TotalTrainers { get; set; }
    public int ActivePlans { get; set; }
    public int ActiveMemberships { get; set; }
    public int ExpiredMemberships { get; set; }
    public int TotalSessions { get; set; }
    public int UpcomingSessions { get; set; }
    public decimal TotalRevenue { get; set; }
    public decimal MonthlyRevenue { get; set; }

    public List<ChartPoint> PlanDistribution { get; set; } = new();
    public List<ChartPoint> MembersGrowth { get; set; } = new();
    public List<MembershipViewModel> ExpiringSoon { get; set; } = new();
    public List<SessionViewModel> NextSessions { get; set; } = new();
}
