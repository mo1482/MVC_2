using System.ComponentModel.DataAnnotations;
using GymManagementSystem.Helpers;
using GymManagementSystem.Models;

namespace GymManagementSystem.ViewModels;

public class TrainerViewModel
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string Phone { get; set; } = null!;
    public string Gender { get; set; } = null!;
    public string Speciality { get; set; } = null!;
    public DateTime HireDate { get; set; }
    public int SessionsCount { get; set; }
}

public class TrainerDetailsViewModel
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string Phone { get; set; } = null!;
    public DateTime DateOfBirth { get; set; }
    public string Gender { get; set; } = null!;
    public string Address { get; set; } = null!;
    public DateTime HireDate { get; set; }
    public string Speciality { get; set; } = null!;
    public int SessionsCount { get; set; }
    public int FutureSessionsCount { get; set; }
    public List<SessionViewModel> UpcomingSessions { get; set; } = new();
}

public class TrainerFormViewModel
{
    public int Id { get; set; }

    [Required, StringLength(50, MinimumLength = 2)]
    public string Name { get; set; } = null!;

    [Required, EmailAddress, StringLength(100)]
    public string Email { get; set; } = null!;

    [Required(ErrorMessage = "Phone is required")]
    [RegularExpression(ValidationPatterns.EgyptianPhone, ErrorMessage = ValidationPatterns.EgyptianPhoneMessage)]
    [Display(Name = "Phone Number")]
    public string Phone { get; set; } = null!;

    [Required, DataType(DataType.Date), PastDate]
    [Display(Name = "Date of Birth")]
    public DateTime? DateOfBirth { get; set; }

    [Required(ErrorMessage = "Please select a gender")]
    public Gender? Gender { get; set; }

    [Required(ErrorMessage = "A trainer must have one specialty assigned")]
    public Speciality? Speciality { get; set; }

    [Required, Range(1, 9999)]
    [Display(Name = "Building #")]
    public int? BuildingNumber { get; set; }

    [Required, StringLength(30)]
    public string Street { get; set; } = null!;

    [Required, StringLength(30)]
    public string City { get; set; } = null!;
}
