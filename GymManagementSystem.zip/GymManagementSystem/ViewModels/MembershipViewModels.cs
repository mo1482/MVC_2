using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GymManagementSystem.ViewModels;

public class MembershipViewModel
{
    public int Id { get; set; }
    public int MemberId { get; set; }
    public string MemberName { get; set; } = null!;
    public string PlanName { get; set; } = null!;
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string Status { get; set; } = null!;
    public bool IsActive { get; set; }
}

public class CreateMembershipViewModel
{
    [Required(ErrorMessage = "Please select a member")]
    [Display(Name = "Member")]
    public int? MemberId { get; set; }

    [Required(ErrorMessage = "Please select a plan")]
    [Display(Name = "Plan")]
    public int? PlanId { get; set; }

    public IEnumerable<SelectListItem>? Members { get; set; }
    public IEnumerable<SelectListItem>? Plans { get; set; }
}
