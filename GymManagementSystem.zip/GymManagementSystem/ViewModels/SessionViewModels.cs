using System.ComponentModel.DataAnnotations;
using GymManagementSystem.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GymManagementSystem.ViewModels;

public class SessionViewModel
{
    public int Id { get; set; }
    public string Description { get; set; } = null!;
    public string Category { get; set; } = null!;
    public int Capacity { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public int TrainerId { get; set; }
    public string TrainerName { get; set; } = null!;
    public string TrainerSpeciality { get; set; } = null!;
    public string Status { get; set; } = null!;
}

public class SessionFormViewModel : IValidatableObject
{
    public int Id { get; set; }

    [Required, StringLength(200)]
    public string Description { get; set; } = null!;

    [Required(ErrorMessage = "Please select a category")]
    public SessionCategory? Category { get; set; }

    [Required, Range(1, 25, ErrorMessage = "Capacity must be between 1 and 25")]
    public int? Capacity { get; set; }

    [Required, DataType(DataType.DateTime)]
    [Display(Name = "Start Date")]
    public DateTime? StartDate { get; set; }

    [Required, DataType(DataType.DateTime)]
    [Display(Name = "End Date")]
    public DateTime? EndDate { get; set; }

    [Required(ErrorMessage = "Please select a trainer")]
    [Display(Name = "Trainer")]
    public int? TrainerId { get; set; }

    public IEnumerable<SelectListItem>? Trainers { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (StartDate.HasValue && EndDate.HasValue && EndDate <= StartDate)
            yield return new ValidationResult("End date must be after start date.", new[] { nameof(EndDate) });
    }
}
