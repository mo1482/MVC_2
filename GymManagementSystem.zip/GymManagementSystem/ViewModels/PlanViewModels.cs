using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.ViewModels;

public class PlanViewModel
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public string Description { get; set; } = null!;
    public int DurationDays { get; set; }
    public decimal Price { get; set; }
    public bool IsActive { get; set; }
    public int ActiveMembers { get; set; }
}

public class PlanFormViewModel
{
    public int Id { get; set; }

    [Required, StringLength(50, MinimumLength = 2)]
    public string Name { get; set; } = null!;

    [Required, StringLength(200)]
    public string Description { get; set; } = null!;

    [Required, Range(1, 365, ErrorMessage = "Duration must be between 1 and 365 days")]
    [Display(Name = "Duration (days)")]
    public int? DurationDays { get; set; }

    [Required, Range(typeof(decimal), "0.01", "100000", ErrorMessage = "Price must be greater than 0")]
    [DataType(DataType.Currency)]
    public decimal? Price { get; set; }

    // Informational only (not posted back)
    public bool IsActive { get; set; }
    public int ActiveMembers { get; set; }
}
