using System.ComponentModel.DataAnnotations;
using GymManagementSystem.Helpers;
using GymManagementSystem.Models;
using Microsoft.AspNetCore.Http;

namespace GymManagementSystem.ViewModels;

public class MemberViewModel
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string Phone { get; set; } = null!;
    public string Gender { get; set; } = null!;
    public string? Photo { get; set; }
    public DateTime JoinDate { get; set; }
    public string? ActivePlan { get; set; }
}

public class MemberDetailsViewModel
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string Phone { get; set; } = null!;
    public DateTime DateOfBirth { get; set; }
    public string Gender { get; set; } = null!;
    public string Address { get; set; } = null!;
    public DateTime JoinDate { get; set; }
    public string? Photo { get; set; }
    public string? ActivePlan { get; set; }
    public List<MembershipViewModel> Memberships { get; set; } = new();

    public int Age
    {
        get
        {
            var today = DateTime.Today;
            var age = today.Year - DateOfBirth.Year;
            if (DateOfBirth.Date > today.AddYears(-age)) age--;
            return age;
        }
    }
}

public class HealthRecordViewModel
{
    public int MemberId { get; set; }
    public string MemberName { get; set; } = null!;
    public string? Photo { get; set; }
    public decimal HeightCm { get; set; }
    public decimal WeightKg { get; set; }
    public string BloodType { get; set; } = null!;
    public string? Note { get; set; }

    public decimal Bmi => HeightCm <= 0 ? 0 : Math.Round(WeightKg / ((HeightCm / 100) * (HeightCm / 100)), 1);

    public string BmiCategory => Bmi switch
    {
        <= 0 => "N/A",
        < 18.5m => "Underweight",
        < 25m => "Normal",
        < 30m => "Overweight",
        _ => "Obese"
    };
}

/// <summary>Used for both Create and Edit of a member (Id = 0 on create).</summary>
public class MemberFormViewModel
{
    public int Id { get; set; }

    [Required, StringLength(50, MinimumLength = 2)]
    public string Name { get; set; } = null!;

    [Required, EmailAddress, StringLength(100)]
    public string Email { get; set; } = null!;

    [Required(ErrorMessage = "Phone is required")]
    [RegularExpression(ValidationPatterns.EgyptianPhone, ErrorMessage = ValidationPatterns.EgyptianPhoneMessage)]
    [Display(Name = "Phone Number")]
    public string Phone { get; set; } = null!;

    [Required, DataType(DataType.Date), PastDate]
    [Display(Name = "Date of Birth")]
    public DateTime? DateOfBirth { get; set; }

    [Required(ErrorMessage = "Please select a gender")]
    public Gender? Gender { get; set; }

    [Required, Range(1, 9999)]
    [Display(Name = "Building #")]
    public int? BuildingNumber { get; set; }

    [Required, StringLength(30)]
    public string Street { get; set; } = null!;

    [Required, StringLength(30)]
    public string City { get; set; } = null!;

    [Display(Name = "Photo")]
    public IFormFile? PhotoFile { get; set; }
    public string? CurrentPhoto { get; set; }

    // Health record
    [Required, Range(typeof(decimal), "50", "250", ErrorMessage = "Height must be between 50 and 250 cm")]
    [Display(Name = "Height (cm)")]
    public decimal? HeightCm { get; set; }

    [Required, Range(typeof(decimal), "20", "400", ErrorMessage = "Weight must be between 20 and 400 kg")]
    [Display(Name = "Weight (kg)")]
    public decimal? WeightKg { get; set; }

    [Required(ErrorMessage = "Please select a blood type")]
    [RegularExpression(ValidationPatterns.BloodType, ErrorMessage = "Invalid blood type")]
    [Display(Name = "Blood Type")]
    public string BloodType { get; set; } = null!;

    [StringLength(500)]
    [Display(Name = "Health Notes")]
    public string? Note { get; set; }
}
