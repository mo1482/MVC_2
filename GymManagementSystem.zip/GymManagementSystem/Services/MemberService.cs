using AutoMapper;
using GymManagementSystem.Data;
using GymManagementSystem.Models;
using GymManagementSystem.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace GymManagementSystem.Services;

public interface IMemberService
{
    Task<List<MemberViewModel>> GetAllAsync(string? search);
    Task<MemberDetailsViewModel?> GetDetailsAsync(int id);
    Task<HealthRecordViewModel?> GetHealthRecordAsync(int id);
    Task<MemberFormViewModel?> GetForEditAsync(int id);
    Task<ServiceResult> CreateAsync(MemberFormViewModel vm);
    Task<ServiceResult> UpdateAsync(int id, MemberFormViewModel vm);
    Task<ServiceResult> DeleteAsync(int id);
}

public class MemberService : IMemberService
{
    private const string PhotoFolder = "members";
    private readonly AppDbContext _db;
    private readonly IMapper _mapper;
    private readonly IPhotoService _photos;

    public MemberService(AppDbContext db, IMapper mapper, IPhotoService photos)
    {
        _db = db;
        _mapper = mapper;
        _photos = photos;
    }

    public async Task<List<MemberViewModel>> GetAllAsync(string? search)
    {
        IQueryable<Member> query = _db.Members.AsNoTracking()
            .Include(m => m.MemberPlans).ThenInclude(mp => mp.Plan);

        if (!string.IsNullOrWhiteSpace(search))
        {
            search = search.Trim();
            query = query.Where(m => m.Name.Contains(search) || m.Email.Contains(search) || m.Phone.Contains(search));
        }

        var members = await query.OrderBy(m => m.Name).ToListAsync();
        return _mapper.Map<List<MemberViewModel>>(members);
    }

    public async Task<MemberDetailsViewModel?> GetDetailsAsync(int id)
    {
        var member = await _db.Members.AsNoTracking()
            .Include(m => m.MemberPlans).ThenInclude(mp => mp.Plan)
            .FirstOrDefaultAsync(m => m.Id == id);
        if (member is null) return null;

        var vm = _mapper.Map<MemberDetailsViewModel>(member);
        foreach (var ms in vm.Memberships) ms.MemberName = member.Name;
        return vm;
    }

    public async Task<HealthRecordViewModel?> GetHealthRecordAsync(int id)
    {
        var member = await _db.Members.AsNoTracking()
            .Include(m => m.HealthRecord)
            .FirstOrDefaultAsync(m => m.Id == id);
        if (member is null) return null;

        return new HealthRecordViewModel
        {
            MemberId = member.Id,
            MemberName = member.Name,
            Photo = member.Photo,
            HeightCm = member.HealthRecord?.HeightCm ?? 0,
            WeightKg = member.HealthRecord?.WeightKg ?? 0,
            BloodType = member.HealthRecord?.BloodType ?? "N/A",
            Note = member.HealthRecord?.Note
        };
    }

    public async Task<MemberFormViewModel?> GetForEditAsync(int id)
    {
        var member = await _db.Members.AsNoTracking()
            .Include(m => m.HealthRecord)
            .FirstOrDefaultAsync(m => m.Id == id);
        return member is null ? null : _mapper.Map<MemberFormViewModel>(member);
    }

    public async Task<ServiceResult> CreateAsync(MemberFormViewModel vm)
    {
        var result = await ValidateAsync(vm, 0);
        if (!result.Succeeded) return result;

        var member = _mapper.Map<Member>(vm);
        member.Address = ToAddress(vm);
        member.JoinDate = DateTime.Now;                       // calculated automatically
        member.HealthRecord = _mapper.Map<HealthRecord>(vm);

        if (vm.PhotoFile is { Length: > 0 })
            member.Photo = await _photos.SaveAsync(vm.PhotoFile, PhotoFolder);

        try
        {
            _db.Members.Add(member);
            await _db.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            _photos.Delete(member.Photo, PhotoFolder);
            return ServiceResult.Fail("The member could not be saved. The email or phone may already be in use.");
        }
        return result;
    }

    public async Task<ServiceResult> UpdateAsync(int id, MemberFormViewModel vm)
    {
        var member = await _db.Members.Include(m => m.HealthRecord).FirstOrDefaultAsync(m => m.Id == id);
        if (member is null) return ServiceResult.Fail("Member not found.");

        var result = await ValidateAsync(vm, id);
        if (!result.Succeeded) return result;

        _mapper.Map(vm, member);
        member.Address.BuildingNumber = vm.BuildingNumber!.Value;
        member.Address.Street = vm.Street.Trim();
        member.Address.City = vm.City.Trim();

        if (member.HealthRecord is null) member.HealthRecord = _mapper.Map<HealthRecord>(vm);
        else _mapper.Map(vm, member.HealthRecord);

        string? oldPhoto = null;
        if (vm.PhotoFile is { Length: > 0 })
        {
            oldPhoto = member.Photo;
            member.Photo = await _photos.SaveAsync(vm.PhotoFile, PhotoFolder);
        }

        try
        {
            await _db.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            return ServiceResult.Fail("The member could not be updated. The email or phone may already be in use.");
        }

        _photos.Delete(oldPhoto, PhotoFolder);
        return result;
    }

    public async Task<ServiceResult> DeleteAsync(int id)
    {
        var member = await _db.Members.Include(m => m.MemberPlans).FirstOrDefaultAsync(m => m.Id == id);
        if (member is null) return ServiceResult.Fail("Member not found.");

        if (member.MemberPlans.Any(mp => mp.EndDate > DateTime.Now))
            return ServiceResult.Fail("Cannot delete a member who has an active membership. Cancel the membership first.");

        var photo = member.Photo;
        _db.Members.Remove(member);
        await _db.SaveChangesAsync();
        _photos.Delete(photo, PhotoFolder);
        return ServiceResult.Ok();
    }

    // ---------------- helpers ----------------
    private async Task<ServiceResult> ValidateAsync(MemberFormViewModel vm, int currentId)
    {
        var result = new ServiceResult();
        vm.Email = vm.Email.Trim();
        vm.Phone = vm.Phone.Trim();

        if (await _db.Members.AnyAsync(m => m.Email == vm.Email && m.Id != currentId))
            result.Add(nameof(vm.Email), "This email is already registered to another member.");
        if (await _db.Members.AnyAsync(m => m.Phone == vm.Phone && m.Id != currentId))
            result.Add(nameof(vm.Phone), "This phone number is already registered to another member.");

        var photoError = _photos.Validate(vm.PhotoFile);
        if (photoError is not null) result.Add(nameof(vm.PhotoFile), photoError);

        return result;
    }

    private static Address ToAddress(MemberFormViewModel vm) => new()
    {
        BuildingNumber = vm.BuildingNumber!.Value,
        Street = vm.Street.Trim(),
        City = vm.City.Trim()
    };
}
