using AutoMapper;
using GymManagementSystem.Data;
using GymManagementSystem.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace GymManagementSystem.Services;

public interface IPlanService
{
    Task<List<PlanViewModel>> GetAllAsync();
    Task<PlanViewModel?> GetDetailsAsync(int id);
    Task<PlanFormViewModel?> GetForEditAsync(int id);
    Task<ServiceResult> UpdateAsync(int id, PlanFormViewModel vm);
    Task<ServiceResult> ToggleActiveAsync(int id);
}

public class PlanService : IPlanService
{
    private readonly AppDbContext _db;
    private readonly IMapper _mapper;

    public PlanService(AppDbContext db, IMapper mapper)
    {
        _db = db;
        _mapper = mapper;
    }

    public async Task<List<PlanViewModel>> GetAllAsync()
    {
        var plans = await _db.Plans.AsNoTracking().Include(p => p.MemberPlans).OrderBy(p => p.DurationDays).ToListAsync();
        return _mapper.Map<List<PlanViewModel>>(plans);
    }

    public async Task<PlanViewModel?> GetDetailsAsync(int id)
    {
        var plan = await _db.Plans.AsNoTracking().Include(p => p.MemberPlans).FirstOrDefaultAsync(p => p.Id == id);
        return plan is null ? null : _mapper.Map<PlanViewModel>(plan);
    }

    public async Task<PlanFormViewModel?> GetForEditAsync(int id)
    {
        var plan = await _db.Plans.AsNoTracking().Include(p => p.MemberPlans).FirstOrDefaultAsync(p => p.Id == id);
        return plan is null ? null : _mapper.Map<PlanFormViewModel>(plan);
    }

    public async Task<ServiceResult> UpdateAsync(int id, PlanFormViewModel vm)
    {
        var plan = await _db.Plans.FirstOrDefaultAsync(p => p.Id == id);
        if (plan is null) return ServiceResult.Fail("Plan not found.");

        if (await HasActiveMembershipsAsync(id))
            return ServiceResult.Fail("Cannot update a plan that has active memberships.");

        _mapper.Map(vm, plan);
        await _db.SaveChangesAsync();
        return ServiceResult.Ok();
    }

    public async Task<ServiceResult> ToggleActiveAsync(int id)
    {
        var plan = await _db.Plans.FirstOrDefaultAsync(p => p.Id == id);
        if (plan is null) return ServiceResult.Fail("Plan not found.");

        // Deactivating (soft delete) is blocked while the plan has active memberships.
        if (plan.IsActive && await HasActiveMembershipsAsync(id))
            return ServiceResult.Fail("Cannot deactivate a plan that has active memberships.");

        plan.IsActive = !plan.IsActive;
        await _db.SaveChangesAsync();
        return ServiceResult.Ok();
    }

    private Task<bool> HasActiveMembershipsAsync(int planId)
        => _db.MemberPlans.AnyAsync(mp => mp.PlanId == planId && mp.EndDate > DateTime.Now);
}
