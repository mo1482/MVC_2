using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace GymManagementSystem.Services;

public class ServiceResult
{
    private readonly List<(string Key, string Message)> _errors = new();

    public bool Succeeded => _errors.Count == 0;
    public IReadOnlyList<(string Key, string Message)> Errors => _errors;
    public string? FirstError => _errors.Count > 0 ? _errors[0].Message : null;

    public ServiceResult Add(string key, string message)
    {
        _errors.Add((key, message));
        return this;
    }

    public static ServiceResult Ok() => new();
    public static ServiceResult Fail(string message, string key = "") => new ServiceResult().Add(key, message);

    public void AddTo(ModelStateDictionary modelState)
    {
        foreach (var (key, message) in _errors)
            modelState.AddModelError(key, message);
    }
}
