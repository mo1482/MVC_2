using AutoMapper;
using GymManagementSystem.Data;
using GymManagementSystem.Models;
using GymManagementSystem.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace GymManagementSystem.Services;

public interface ISessionService
{
    Task<List<SessionViewModel>> GetAllAsync();
    Task<SessionViewModel?> GetDetailsAsync(int id);
    Task<SessionFormViewModel?> GetForEditAsync(int id);
    Task<List<SelectListItem>> GetTrainersSelectListAsync();
    Task<ServiceResult> CreateAsync(SessionFormViewModel vm);
    Task<ServiceResult> UpdateAsync(int id, SessionFormViewModel vm);
    Task<ServiceResult> DeleteAsync(int id);
}

public class SessionService : ISessionService
{
    private readonly AppDbContext _db;
    private readonly IMapper _mapper;

    public SessionService(AppDbContext db, IMapper mapper)
    {
        _db = db;
        _mapper = mapper;
    }

    public async Task<List<SessionViewModel>> GetAllAsync()
    {
        var sessions = await _db.Sessions.AsNoTracking()
            .Include(s => s.Trainer)
            .OrderByDescending(s => s.StartDate)
            .ToListAsync();
        return _mapper.Map<List<SessionViewModel>>(sessions);
    }

    public async Task<SessionViewModel?> GetDetailsAsync(int id)
    {
        var session = await _db.Sessions.AsNoTracking().Include(s => s.Trainer).FirstOrDefaultAsync(s => s.Id == id);
        return session is null ? null : _mapper.Map<SessionViewModel>(session);
    }

    public async Task<SessionFormViewModel?> GetForEditAsync(int id)
    {
        var session = await _db.Sessions.AsNoTracking().FirstOrDefaultAsync(s => s.Id == id);
        return session is null ? null : _mapper.Map<SessionFormViewModel>(session);
    }

    public async Task<List<SelectListItem>> GetTrainersSelectListAsync()
    {
        var trainers = await _db.Trainers.AsNoTracking().OrderBy(t => t.Name).ToListAsync();
        return trainers
            .Select(t => new SelectListItem { Value = t.Id.ToString(), Text = $"{t.Name} ({t.Speciality})" })
            .ToList();
    }

    public async Task<ServiceResult> CreateAsync(SessionFormViewModel vm)
    {
        var result = await ValidateAsync(vm);
        if (!result.Succeeded) return result;

        _db.Sessions.Add(_mapper.Map<Session>(vm));
        await _db.SaveChangesAsync();
        return result;
    }

    public async Task<ServiceResult> UpdateAsync(int id, SessionFormViewModel vm)
    {
        var session = await _db.Sessions.FirstOrDefaultAsync(s => s.Id == id);
        if (session is null) return ServiceResult.Fail("Session not found.");

        var result = await ValidateAsync(vm);
        if (!result.Succeeded) return result;

        _mapper.Map(vm, session);
        await _db.SaveChangesAsync();
        return result;
    }

    public async Task<ServiceResult> DeleteAsync(int id)
    {
        var session = await _db.Sessions.FirstOrDefaultAsync(s => s.Id == id);
        if (session is null) return ServiceResult.Fail("Session not found.");

        _db.Sessions.Remove(session);
        await _db.SaveChangesAsync();
        return ServiceResult.Ok();
    }

    private async Task<ServiceResult> ValidateAsync(SessionFormViewModel vm)
    {
        var result = new ServiceResult();
        if (vm.StartDate.HasValue && vm.EndDate.HasValue && vm.EndDate <= vm.StartDate)
            result.Add(nameof(vm.EndDate), "End date must be after start date.");
        if (vm.Capacity is < 1 or > 25)
            result.Add(nameof(vm.Capacity), "Capacity must be between 1 and 25.");
        if (!await _db.Trainers.AnyAsync(t => t.Id == vm.TrainerId))
            result.Add(nameof(vm.TrainerId), "The selected trainer does not exist.");
        return result;
    }
}
