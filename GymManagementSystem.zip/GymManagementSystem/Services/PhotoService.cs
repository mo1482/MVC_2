namespace GymManagementSystem.Services;

public interface IPhotoService
{
    string? Validate(IFormFile? file);
    Task<string> SaveAsync(IFormFile file, string folder);
    void Delete(string? fileName, string folder);
}

public class PhotoService : IPhotoService
{
    private static readonly string[] AllowedExtensions = { ".jpg", ".jpeg", ".png" };
    private const long MaxSizeBytes = 2 * 1024 * 1024;
    private readonly IWebHostEnvironment _env;

    public PhotoService(IWebHostEnvironment env) => _env = env;

    public string? Validate(IFormFile? file)
    {
        if (file is null || file.Length == 0) return null;
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!AllowedExtensions.Contains(ext)) return "Only .jpg, .jpeg and .png images are allowed.";
        if (file.Length > MaxSizeBytes) return "Image size must not exceed 2 MB.";
        return null;
    }

    public async Task<string> SaveAsync(IFormFile file, string folder)
    {
        var dir = Path.Combine(_env.WebRootPath, "images", folder);
        Directory.CreateDirectory(dir);
        var fileName = $"{Guid.NewGuid():N}{Path.GetExtension(file.FileName).ToLowerInvariant()}";
        await using var stream = new FileStream(Path.Combine(dir, fileName), FileMode.Create);
        await file.CopyToAsync(stream);
        return fileName;
    }

    public void Delete(string? fileName, string folder)
    {
        if (string.IsNullOrWhiteSpace(fileName)) return;
        var path = Path.Combine(_env.WebRootPath, "images", folder, Path.GetFileName(fileName));
        if (File.Exists(path)) File.Delete(path);
    }
}
