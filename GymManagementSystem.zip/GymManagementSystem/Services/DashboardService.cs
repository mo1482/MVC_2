using AutoMapper;
using GymManagementSystem.Data;
using GymManagementSystem.Models;
using GymManagementSystem.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace GymManagementSystem.Services;

public interface IDashboardService
{
    Task<HomeViewModel> GetHomeAsync();
    Task<DashboardViewModel> GetDashboardAsync();
}

public class DashboardService : IDashboardService
{
    private readonly AppDbContext _db;
    private readonly IMapper _mapper;

    public DashboardService(AppDbContext db, IMapper mapper)
    {
        _db = db;
        _mapper = mapper;
    }

    public async Task<HomeViewModel> GetHomeAsync()
    {
        var now = DateTime.Now;
        return new HomeViewModel
        {
            TotalMembers = await _db.Members.CountAsync(),
            TotalTrainers = await _db.Trainers.CountAsync(),
            ActivePlans = await _db.Plans.CountAsync(p => p.IsActive),
            UpcomingSessions = await _db.Sessions.CountAsync(s => s.StartDate > now)
        };
    }

    public async Task<DashboardViewModel> GetDashboardAsync()
    {
        var now = DateTime.Now;
        var monthStart = new DateTime(now.Year, now.Month, 1);
        var growthFrom = monthStart.AddMonths(-5);
        var soon = now.AddDays(7);

        var vm = new DashboardViewModel
        {
            TotalMembers = await _db.Members.CountAsync(),
            NewMembersThisMonth = await _db.Members.CountAsync(m => m.JoinDate >= monthStart),
            MaleMembers = await _db.Members.CountAsync(m => m.Gender == Gender.Male),
            FemaleMembers = await _db.Members.CountAsync(m => m.Gender == Gender.Female),
            TotalTrainers = await _db.Trainers.CountAsync(),
            ActivePlans = await _db.Plans.CountAsync(p => p.IsActive),
            ActiveMemberships = await _db.MemberPlans.CountAsync(mp => mp.EndDate > now),
            ExpiredMemberships = await _db.MemberPlans.CountAsync(mp => mp.EndDate <= now),
            TotalSessions = await _db.Sessions.CountAsync(),
            UpcomingSessions = await _db.Sessions.CountAsync(s => s.StartDate > now),
            TotalRevenue = await _db.MemberPlans.SumAsync(mp => mp.Plan.Price),
            MonthlyRevenue = await _db.MemberPlans.Where(mp => mp.StartDate >= monthStart).SumAsync(mp => mp.Plan.Price)
        };

        vm.PlanDistribution = await _db.MemberPlans
            .Where(mp => mp.EndDate > now)
            .GroupBy(mp => mp.Plan.Name)
            .Select(g => new ChartPoint { Label = g.Key, Value = g.Count() })
            .ToListAsync();

        var joinDates = await _db.Members.Where(m => m.JoinDate >= growthFrom).Select(m => m.JoinDate).ToListAsync();
        for (var i = 0; i < 6; i++)
        {
            var month = growthFrom.AddMonths(i);
            vm.MembersGrowth.Add(new ChartPoint
            {
                Label = month.ToString("MMM yyyy"),
                Value = joinDates.Count(d => d.Year == month.Year && d.Month == month.Month)
            });
        }

        var expiring = await _db.MemberPlans.AsNoTracking()
            .Include(mp => mp.Member).Include(mp => mp.Plan)
            .Where(mp => mp.EndDate > now && mp.EndDate <= soon)
            .OrderBy(mp => mp.EndDate)
            .Take(8)
            .ToListAsync();
        vm.ExpiringSoon = _mapper.Map<List<MembershipViewModel>>(expiring);

        var nextSessions = await _db.Sessions.AsNoTracking()
            .Include(s => s.Trainer)
            .Where(s => s.StartDate > now)
            .OrderBy(s => s.StartDate)
            .Take(5)
            .ToListAsync();
        vm.NextSessions = _mapper.Map<List<SessionViewModel>>(nextSessions);

        return vm;
    }
}
