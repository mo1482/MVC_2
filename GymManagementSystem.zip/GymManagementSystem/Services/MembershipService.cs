using AutoMapper;
using GymManagementSystem.Data;
using GymManagementSystem.Models;
using GymManagementSystem.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace GymManagementSystem.Services;

public interface IMembershipService
{
    Task<List<MembershipViewModel>> GetAllAsync(string? status);
    Task<CreateMembershipViewModel> GetCreateFormAsync(CreateMembershipViewModel? vm = null);
    Task<ServiceResult> CreateAsync(CreateMembershipViewModel vm);
    Task<ServiceResult> CancelAsync(int id);
}

public class MembershipService : IMembershipService
{
    private readonly AppDbContext _db;
    private readonly IMapper _mapper;

    public MembershipService(AppDbContext db, IMapper mapper)
    {
        _db = db;
        _mapper = mapper;
    }

    public async Task<List<MembershipViewModel>> GetAllAsync(string? status)
    {
        IQueryable<MemberPlan> query = _db.MemberPlans.AsNoTracking().Include(mp => mp.Member).Include(mp => mp.Plan);
        var now = DateTime.Now;

        if (string.Equals(status, "active", StringComparison.OrdinalIgnoreCase))
            query = query.Where(mp => mp.EndDate > now);
        else if (string.Equals(status, "expired", StringComparison.OrdinalIgnoreCase))
            query = query.Where(mp => mp.EndDate <= now);

        var list = await query.OrderByDescending(mp => mp.StartDate).ToListAsync();
        return _mapper.Map<List<MembershipViewModel>>(list);
    }

    public async Task<CreateMembershipViewModel> GetCreateFormAsync(CreateMembershipViewModel? vm = null)
    {
        vm ??= new CreateMembershipViewModel();
        var now = DateTime.Now;

        // Members without an active membership, and active plans only.
        var members = await _db.Members.AsNoTracking()
            .Where(m => !m.MemberPlans.Any(mp => mp.EndDate > now))
            .OrderBy(m => m.Name)
            .ToListAsync();
        vm.Members = members
            .Select(m => new SelectListItem { Value = m.Id.ToString(), Text = $"{m.Name} - {m.Phone}" })
            .ToList();

        var plans = await _db.Plans.AsNoTracking()
            .Where(p => p.IsActive)
            .OrderBy(p => p.DurationDays)
            .ToListAsync();
        vm.Plans = plans
            .Select(p => new SelectListItem { Value = p.Id.ToString(), Text = $"{p.Name} - {p.DurationDays} days - {p.Price:0.##} EGP" })
            .ToList();

        return vm;
    }

    public async Task<ServiceResult> CreateAsync(CreateMembershipViewModel vm)
    {
        var result = new ServiceResult();

        var member = await _db.Members.FirstOrDefaultAsync(m => m.Id == vm.MemberId);
        if (member is null) return result.Add(nameof(vm.MemberId), "The selected member does not exist.");

        var plan = await _db.Plans.FirstOrDefaultAsync(p => p.Id == vm.PlanId);
        if (plan is null) return result.Add(nameof(vm.PlanId), "The selected plan does not exist.");

        // Only active plans can be assigned
        if (!plan.IsActive)
            result.Add(nameof(vm.PlanId), "Only active plans can be assigned to members.");

        // A member cannot have more than one active membership at the same time
        if (await _db.MemberPlans.AnyAsync(mp => mp.MemberId == member.Id && mp.EndDate > DateTime.Now))
            result.Add(nameof(vm.MemberId), "This member already has an active membership.");

        if (!result.Succeeded) return result;

        var start = DateTime.Now;
        _db.MemberPlans.Add(new MemberPlan
        {
            MemberId = member.Id,
            PlanId = plan.Id,
            StartDate = start,
            EndDate = start.AddDays(plan.DurationDays)   // calculated from the plan duration
        });
        await _db.SaveChangesAsync();
        return result;
    }

    public async Task<ServiceResult> CancelAsync(int id)
    {
        var membership = await _db.MemberPlans.FirstOrDefaultAsync(mp => mp.Id == id);
        if (membership is null) return ServiceResult.Fail("Membership not found.");
        if (!membership.IsActive) return ServiceResult.Fail("Only active memberships can be cancelled.");

        // Ending the membership now turns its computed status into "Expired".
        membership.EndDate = DateTime.Now;
        if (membership.EndDate < membership.StartDate) membership.EndDate = membership.StartDate;
        await _db.SaveChangesAsync();
        return ServiceResult.Ok();
    }
}
