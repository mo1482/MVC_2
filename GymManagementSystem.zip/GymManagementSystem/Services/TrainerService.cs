using AutoMapper;
using GymManagementSystem.Data;
using GymManagementSystem.Models;
using GymManagementSystem.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace GymManagementSystem.Services;

public interface ITrainerService
{
    Task<List<TrainerViewModel>> GetAllAsync(string? search);
    Task<TrainerDetailsViewModel?> GetDetailsAsync(int id);
    Task<TrainerFormViewModel?> GetForEditAsync(int id);
    Task<ServiceResult> CreateAsync(TrainerFormViewModel vm);
    Task<ServiceResult> UpdateAsync(int id, TrainerFormViewModel vm);
    Task<ServiceResult> DeleteAsync(int id);
}

public class TrainerService : ITrainerService
{
    private readonly AppDbContext _db;
    private readonly IMapper _mapper;

    public TrainerService(AppDbContext db, IMapper mapper)
    {
        _db = db;
        _mapper = mapper;
    }

    public async Task<List<TrainerViewModel>> GetAllAsync(string? search)
    {
        IQueryable<Trainer> query = _db.Trainers.AsNoTracking().Include(t => t.Sessions);

        if (!string.IsNullOrWhiteSpace(search))
        {
            search = search.Trim();
            query = query.Where(t => t.Name.Contains(search) || t.Email.Contains(search) || t.Phone.Contains(search));
        }

        var trainers = await query.OrderBy(t => t.Name).ToListAsync();
        return _mapper.Map<List<TrainerViewModel>>(trainers);
    }

    public async Task<TrainerDetailsViewModel?> GetDetailsAsync(int id)
    {
        var trainer = await _db.Trainers.AsNoTracking()
            .Include(t => t.Sessions)
            .FirstOrDefaultAsync(t => t.Id == id);
        if (trainer is null) return null;

        var vm = _mapper.Map<TrainerDetailsViewModel>(trainer);
        foreach (var s in vm.UpcomingSessions)
        {
            s.TrainerName = trainer.Name;
            s.TrainerSpeciality = trainer.Speciality.ToString();
        }
        return vm;
    }

    public async Task<TrainerFormViewModel?> GetForEditAsync(int id)
    {
        var trainer = await _db.Trainers.AsNoTracking().FirstOrDefaultAsync(t => t.Id == id);
        return trainer is null ? null : _mapper.Map<TrainerFormViewModel>(trainer);
    }

    public async Task<ServiceResult> CreateAsync(TrainerFormViewModel vm)
    {
        var result = await ValidateAsync(vm, 0);
        if (!result.Succeeded) return result;

        var trainer = _mapper.Map<Trainer>(vm);
        trainer.Address = ToAddress(vm);
        trainer.HireDate = DateTime.Now;                      // calculated automatically

        try
        {
            _db.Trainers.Add(trainer);
            await _db.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            return ServiceResult.Fail("The trainer could not be saved. The email or phone may already be in use.");
        }
        return result;
    }

    public async Task<ServiceResult> UpdateAsync(int id, TrainerFormViewModel vm)
    {
        var trainer = await _db.Trainers.FirstOrDefaultAsync(t => t.Id == id);
        if (trainer is null) return ServiceResult.Fail("Trainer not found.");

        var result = await ValidateAsync(vm, id);
        if (!result.Succeeded) return result;

        _mapper.Map(vm, trainer);
        trainer.Address.BuildingNumber = vm.BuildingNumber!.Value;
        trainer.Address.Street = vm.Street.Trim();
        trainer.Address.City = vm.City.Trim();

        try
        {
            await _db.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            return ServiceResult.Fail("The trainer could not be updated. The email or phone may already be in use.");
        }
        return result;
    }

    public async Task<ServiceResult> DeleteAsync(int id)
    {
        var trainer = await _db.Trainers.Include(t => t.Sessions).FirstOrDefaultAsync(t => t.Id == id);
        if (trainer is null) return ServiceResult.Fail("Trainer not found.");

        if (trainer.Sessions.Any(s => s.StartDate > DateTime.Now))
            return ServiceResult.Fail("Cannot delete a trainer who has future sessions. Reassign or delete those sessions first.");

        _db.Trainers.Remove(trainer);   // past sessions are removed by cascade
        await _db.SaveChangesAsync();
        return ServiceResult.Ok();
    }

    // ---------------- helpers ----------------
    private async Task<ServiceResult> ValidateAsync(TrainerFormViewModel vm, int currentId)
    {
        var result = new ServiceResult();
        vm.Email = vm.Email.Trim();
        vm.Phone = vm.Phone.Trim();

        if (await _db.Trainers.AnyAsync(t => t.Email == vm.Email && t.Id != currentId))
            result.Add(nameof(vm.Email), "This email is already registered to another trainer.");
        if (await _db.Trainers.AnyAsync(t => t.Phone == vm.Phone && t.Id != currentId))
            result.Add(nameof(vm.Phone), "This phone number is already registered to another trainer.");
        return result;
    }

    private static Address ToAddress(TrainerFormViewModel vm) => new()
    {
        BuildingNumber = vm.BuildingNumber!.Value,
        Street = vm.Street.Trim(),
        City = vm.City.Trim()
    };
}
