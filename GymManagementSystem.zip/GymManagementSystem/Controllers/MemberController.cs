using GymManagementSystem.Services;
using GymManagementSystem.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace GymManagementSystem.Controllers;

public class MemberController : BaseController
{
    private readonly IMemberService _service;

    public MemberController(IMemberService service) => _service = service;

    // Members listing page
    public async Task<IActionResult> Index(string? search)
    {
        ViewBag.Search = search;
        return View(await _service.GetAllAsync(search));
    }

    // Member registration form
    [HttpGet]
    public IActionResult Create() => View(new MemberFormViewModel());

    // Form submission
    [HttpPost]
    public async Task<IActionResult> CreateMember(MemberFormViewModel vm)
    {
        if (!ModelState.IsValid) return View(nameof(Create), vm);

        var result = await _service.CreateAsync(vm);
        if (!result.Succeeded)
        {
            result.AddTo(ModelState);
            return View(nameof(Create), vm);
        }

        Success("Member registered successfully.");
        return RedirectToAction(nameof(Index));
    }

    // Member profile page
    public async Task<IActionResult> MemberDetails(int id)
    {
        var vm = await _service.GetDetailsAsync(id);
        return vm is null ? NotFoundRedirect("Member") : View(vm);
    }

    // Health record page
    public async Task<IActionResult> HealthRecordDetails(int id)
    {
        var vm = await _service.GetHealthRecordAsync(id);
        return vm is null ? NotFoundRedirect("Member") : View(vm);
    }

    // Edit form
    [HttpGet]
    public async Task<IActionResult> MemberEdit(int id)
    {
        var vm = await _service.GetForEditAsync(id);
        return vm is null ? NotFoundRedirect("Member") : View(vm);
    }

    // Process update
    [HttpPost]
    public async Task<IActionResult> MemberEdit(int id, MemberFormViewModel vm)
    {
        vm.Id = id;
        if (!ModelState.IsValid) return View(vm);

        var result = await _service.UpdateAsync(id, vm);
        if (!result.Succeeded)
        {
            result.AddTo(ModelState);
            return View(vm);
        }

        Success("Member updated successfully.");
        return RedirectToAction(nameof(MemberDetails), new { id });
    }

    // Deletion confirmation page
    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var vm = await _service.GetDetailsAsync(id);
        return vm is null ? NotFoundRedirect("Member") : View(vm);
    }

    // Process deletion
    [HttpPost]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var result = await _service.DeleteAsync(id);
        if (result.Succeeded) Success("Member deleted successfully.");
        else Error(result.FirstError!);
        return RedirectToAction(nameof(Index));
    }
}
