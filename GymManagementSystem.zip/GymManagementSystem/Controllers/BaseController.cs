using Microsoft.AspNetCore.Mvc;

namespace GymManagementSystem.Controllers;

public abstract class BaseController : Controller
{
    protected void Success(string message) => TempData["Success"] = message;
    protected void Error(string message) => TempData["Error"] = message;

    protected IActionResult NotFoundRedirect(string entity, string action = "Index")
    {
        Error($"{entity} not found.");
        return RedirectToAction(action);
    }
}
