using GymManagementSystem.Services;
using GymManagementSystem.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace GymManagementSystem.Controllers;

public class TrainerController : BaseController
{
    private readonly ITrainerService _service;

    public TrainerController(ITrainerService service) => _service = service;

    // Trainer listing page
    public async Task<IActionResult> Index(string? search)
    {
        ViewBag.Search = search;
        return View(await _service.GetAllAsync(search));
    }

    // Trainer registration form
    [HttpGet]
    public IActionResult Create() => View(new TrainerFormViewModel());

    // Form submission handler
    [HttpPost]
    public async Task<IActionResult> CreateTrainer(TrainerFormViewModel vm)
    {
        if (!ModelState.IsValid) return View(nameof(Create), vm);

        var result = await _service.CreateAsync(vm);
        if (!result.Succeeded)
        {
            result.AddTo(ModelState);
            return View(nameof(Create), vm);
        }

        Success("Trainer registered successfully.");
        return RedirectToAction(nameof(Index));
    }

    // Trainer profile page
    public async Task<IActionResult> Details(int id)
    {
        var vm = await _service.GetDetailsAsync(id);
        return vm is null ? NotFoundRedirect("Trainer") : View(vm);
    }

    // Edit form display
    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var vm = await _service.GetForEditAsync(id);
        return vm is null ? NotFoundRedirect("Trainer") : View(vm);
    }

    // Update handler
    [HttpPost]
    public async Task<IActionResult> Edit(int id, TrainerFormViewModel vm)
    {
        vm.Id = id;
        if (!ModelState.IsValid) return View(vm);

        var result = await _service.UpdateAsync(id, vm);
        if (!result.Succeeded)
        {
            result.AddTo(ModelState);
            return View(vm);
        }

        Success("Trainer updated successfully.");
        return RedirectToAction(nameof(Details), new { id });
    }

    // Deletion confirmation page
    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var vm = await _service.GetDetailsAsync(id);
        return vm is null ? NotFoundRedirect("Trainer") : View(vm);
    }

    // Process deletion
    [HttpPost]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var result = await _service.DeleteAsync(id);
        if (result.Succeeded) Success("Trainer deleted successfully.");
        else Error(result.FirstError!);
        return RedirectToAction(nameof(Index));
    }
}
