using GymManagementSystem.Services;
using GymManagementSystem.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace GymManagementSystem.Controllers;

public class SessionController : BaseController
{
    private readonly ISessionService _service;

    public SessionController(ISessionService service) => _service = service;

    // Session calendar / list page
    public async Task<IActionResult> Index() => View(await _service.GetAllAsync());

    // New session form with trainer / category dropdowns
    [HttpGet]
    public async Task<IActionResult> Create()
    {
        var start = DateTime.Now.Date.AddHours(DateTime.Now.Hour + 1);
        var vm = new SessionFormViewModel
        {
            StartDate = start,
            EndDate = start.AddHours(1),
            Capacity = 10,
            Trainers = await _service.GetTrainersSelectListAsync()
        };
        return View(vm);
    }

    // Session creation handler
    [HttpPost]
    public async Task<IActionResult> Create(SessionFormViewModel vm)
    {
        if (ModelState.IsValid)
        {
            var result = await _service.CreateAsync(vm);
            if (result.Succeeded)
            {
                Success("Session created successfully.");
                return RedirectToAction(nameof(Index));
            }
            result.AddTo(ModelState);
        }

        vm.Trainers = await _service.GetTrainersSelectListAsync();
        return View(vm);
    }

    // Session details page
    public async Task<IActionResult> Details(int id)
    {
        var vm = await _service.GetDetailsAsync(id);
        return vm is null ? NotFoundRedirect("Session") : View(vm);
    }

    // Session edit form
    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var vm = await _service.GetForEditAsync(id);
        if (vm is null) return NotFoundRedirect("Session");
        vm.Trainers = await _service.GetTrainersSelectListAsync();
        return View(vm);
    }

    // Update handler
    [HttpPost]
    public async Task<IActionResult> Edit(int id, SessionFormViewModel vm)
    {
        vm.Id = id;
        if (ModelState.IsValid)
        {
            var result = await _service.UpdateAsync(id, vm);
            if (result.Succeeded)
            {
                Success("Session updated successfully.");
                return RedirectToAction(nameof(Details), new { id });
            }
            result.AddTo(ModelState);
        }

        vm.Trainers = await _service.GetTrainersSelectListAsync();
        return View(vm);
    }

    // Deletion confirmation page
    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var vm = await _service.GetDetailsAsync(id);
        return vm is null ? NotFoundRedirect("Session") : View(vm);
    }

    // Process deletion
    [HttpPost]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var result = await _service.DeleteAsync(id);
        if (result.Succeeded) Success("Session deleted successfully.");
        else Error(result.FirstError!);
        return RedirectToAction(nameof(Index));
    }
}
