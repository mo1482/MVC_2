using GymManagementSystem.Services;
using GymManagementSystem.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace GymManagementSystem.Controllers;

public class PlanController : BaseController
{
    private readonly IPlanService _service;

    public PlanController(IPlanService service) => _service = service;

    // Plans listing page
    public async Task<IActionResult> Index() => View(await _service.GetAllAsync());

    // Plan details page
    public async Task<IActionResult> Details(int id)
    {
        var vm = await _service.GetDetailsAsync(id);
        return vm is null ? NotFoundRedirect("Plan") : View(vm);
    }

    // Plan edit form
    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var vm = await _service.GetForEditAsync(id);
        return vm is null ? NotFoundRedirect("Plan") : View(vm);
    }

    // Update handler
    [HttpPost]
    public async Task<IActionResult> Edit(int id, PlanFormViewModel vm)
    {
        vm.Id = id;
        if (!ModelState.IsValid) return View(vm);

        var result = await _service.UpdateAsync(id, vm);
        if (!result.Succeeded)
        {
            result.AddTo(ModelState);
            return View(vm);
        }

        Success("Plan updated successfully.");
        return RedirectToAction(nameof(Index));
    }

    // Toggle plan active status (activate / deactivate = soft delete)
    [HttpPost]
    public async Task<IActionResult> Activate(int id)
    {
        var result = await _service.ToggleActiveAsync(id);
        if (result.Succeeded) Success("Plan status updated successfully.");
        else Error(result.FirstError!);
        return RedirectToAction(nameof(Index));
    }
}
