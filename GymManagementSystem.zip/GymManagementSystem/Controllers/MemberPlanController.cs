using GymManagementSystem.Services;
using GymManagementSystem.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace GymManagementSystem.Controllers;

public class MemberPlanController : BaseController
{
    private readonly IMembershipService _service;

    public MemberPlanController(IMembershipService service) => _service = service;

    // Memberships listing page
    public async Task<IActionResult> Index(string? status)
    {
        ViewBag.Status = status;
        return View(await _service.GetAllAsync(status));
    }

    // Membership registration form
    [HttpGet]
    public async Task<IActionResult> Create() => View(await _service.GetCreateFormAsync());

    // Form submission handler
    [HttpPost]
    public async Task<IActionResult> Create(CreateMembershipViewModel vm)
    {
        if (ModelState.IsValid)
        {
            var result = await _service.CreateAsync(vm);
            if (result.Succeeded)
            {
                Success("Membership created successfully.");
                return RedirectToAction(nameof(Index));
            }
            result.AddTo(ModelState);
        }

        return View(await _service.GetCreateFormAsync(vm));
    }

    // Process cancellation of a membership
    [HttpPost]
    public async Task<IActionResult> Cancel(int id)
    {
        var result = await _service.CancelAsync(id);
        if (result.Succeeded) Success("Membership cancelled successfully.");
        else Error(result.FirstError!);
        return RedirectToAction(nameof(Index));
    }
}
