using GymManagementSystem.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace GymManagementSystem.Data;

public class AppDbContext : IdentityDbContext<ApplicationUser>
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Member> Members => Set<Member>();
    public DbSet<HealthRecord> HealthRecords => Set<HealthRecord>();
    public DbSet<Trainer> Trainers => Set<Trainer>();
    public DbSet<Plan> Plans => Set<Plan>();
    public DbSet<Session> Sessions => Set<Session>();
    public DbSet<MemberPlan> MemberPlans => Set<MemberPlan>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
    }
}
