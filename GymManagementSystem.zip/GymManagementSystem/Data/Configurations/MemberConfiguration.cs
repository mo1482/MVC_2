using GymManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GymManagementSystem.Data.Configurations;

public class MemberConfiguration : IEntityTypeConfiguration<Member>
{
    public void Configure(EntityTypeBuilder<Member> builder)
    {
        builder.Property(m => m.Name).HasColumnType("varchar(50)").IsRequired();
        builder.Property(m => m.Email).HasColumnType("varchar(100)").IsRequired();
        builder.Property(m => m.Phone).HasColumnType("varchar(11)").IsRequired();
        builder.Property(m => m.DateOfBirth).HasColumnType("date");
        builder.Property(m => m.Gender).HasConversion<string>().HasMaxLength(10);
        builder.Property(m => m.Photo).HasColumnType("varchar(100)");

        // JoinDate = insertion date
        builder.Property(m => m.JoinDate).HasDefaultValueSql("GETDATE()");

        builder.HasIndex(m => m.Email).IsUnique();
        builder.HasIndex(m => m.Phone).IsUnique();

        builder.ToTable(t => t.HasCheckConstraint("CK_Members_Phone",
            "[Phone] LIKE '01[0125][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'"));

        builder.OwnsOne(m => m.Address, a =>
        {
            a.Property(x => x.BuildingNumber).HasColumnName("BuildingNumber");
            a.Property(x => x.Street).HasColumnName("Street").HasColumnType("varchar(30)").IsRequired();
            a.Property(x => x.City).HasColumnName("City").HasColumnType("varchar(30)").IsRequired();
        });
        builder.Navigation(m => m.Address).IsRequired();

        builder.HasOne(m => m.HealthRecord)
               .WithOne(h => h.Member)
               .HasForeignKey<HealthRecord>(h => h.Id)
               .OnDelete(DeleteBehavior.Cascade);

        builder.HasMany(m => m.MemberPlans)
               .WithOne(mp => mp.Member)
               .HasForeignKey(mp => mp.MemberId)
               .OnDelete(DeleteBehavior.Cascade);
    }
}
