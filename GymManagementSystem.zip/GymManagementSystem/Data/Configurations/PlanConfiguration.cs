using GymManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GymManagementSystem.Data.Configurations;

public class PlanConfiguration : IEntityTypeConfiguration<Plan>
{
    public void Configure(EntityTypeBuilder<Plan> builder)
    {
        builder.Property(p => p.Name).HasColumnType("varchar(50)").IsRequired();
        builder.Property(p => p.Description).HasColumnType("varchar(200)").IsRequired();
        builder.Property(p => p.Price).HasColumnType("decimal(10,2)");

        builder.ToTable(t =>
        {
            t.HasCheckConstraint("CK_Plans_DurationDays", "[DurationDays] BETWEEN 1 AND 365");
            t.HasCheckConstraint("CK_Plans_Price", "[Price] > 0");
        });

        builder.HasMany(p => p.MemberPlans)
               .WithOne(mp => mp.Plan)
               .HasForeignKey(mp => mp.PlanId)
               .OnDelete(DeleteBehavior.Restrict);
    }
}
