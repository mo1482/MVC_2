using GymManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GymManagementSystem.Data.Configurations;

public class TrainerConfiguration : IEntityTypeConfiguration<Trainer>
{
    public void Configure(EntityTypeBuilder<Trainer> builder)
    {
        builder.Property(t => t.Name).HasColumnType("varchar(50)").IsRequired();
        builder.Property(t => t.Email).HasColumnType("varchar(100)").IsRequired();
        builder.Property(t => t.Phone).HasColumnType("varchar(11)").IsRequired();
        builder.Property(t => t.DateOfBirth).HasColumnType("date");
        builder.Property(t => t.Gender).HasConversion<string>().HasMaxLength(10);
        builder.Property(t => t.Speciality).HasConversion<string>().HasMaxLength(20).IsRequired();

        // HireDate = insertion date
        builder.Property(t => t.HireDate).HasDefaultValueSql("GETDATE()");

        builder.HasIndex(t => t.Email).IsUnique();
        builder.HasIndex(t => t.Phone).IsUnique();

        builder.ToTable(t => t.HasCheckConstraint("CK_Trainers_Phone",
            "[Phone] LIKE '01[0125][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'"));

        builder.OwnsOne(t => t.Address, a =>
        {
            a.Property(x => x.BuildingNumber).HasColumnName("BuildingNumber");
            a.Property(x => x.Street).HasColumnName("Street").HasColumnType("varchar(30)").IsRequired();
            a.Property(x => x.City).HasColumnName("City").HasColumnType("varchar(30)").IsRequired();
        });
        builder.Navigation(t => t.Address).IsRequired();

        // A Trainer conducts many Sessions (deleting a trainer is blocked by the service while future sessions exist)
        builder.HasMany(t => t.Sessions)
               .WithOne(s => s.Trainer)
               .HasForeignKey(s => s.TrainerId)
               .OnDelete(DeleteBehavior.Cascade);
    }
}
