using GymManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GymManagementSystem.Data.Configurations;

public class HealthRecordConfiguration : IEntityTypeConfiguration<HealthRecord>
{
    public void Configure(EntityTypeBuilder<HealthRecord> builder)
    {
        builder.Property(h => h.Id).ValueGeneratedNever();
        builder.Property(h => h.HeightCm).HasColumnType("decimal(5,1)");
        builder.Property(h => h.WeightKg).HasColumnType("decimal(5,1)");
        builder.Property(h => h.BloodType).HasColumnType("varchar(3)").IsRequired();
        builder.Property(h => h.Note).HasColumnType("varchar(500)");
    }
}
