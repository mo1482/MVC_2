using GymManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GymManagementSystem.Data.Configurations;

public class SessionConfiguration : IEntityTypeConfiguration<Session>
{
    public void Configure(EntityTypeBuilder<Session> builder)
    {
        builder.Property(s => s.Description).HasColumnType("varchar(200)").IsRequired();
        builder.Property(s => s.Category).HasConversion<string>().HasMaxLength(20);

        builder.ToTable(t =>
        {
            t.HasCheckConstraint("CK_Sessions_Capacity", "[Capacity] BETWEEN 1 AND 25");
            t.HasCheckConstraint("CK_Sessions_EndDate", "[EndDate] > [StartDate]");
        });
    }
}
