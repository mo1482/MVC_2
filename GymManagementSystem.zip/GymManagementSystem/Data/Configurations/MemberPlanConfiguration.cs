using GymManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GymManagementSystem.Data.Configurations;

public class MemberPlanConfiguration : IEntityTypeConfiguration<MemberPlan>
{
    public void Configure(EntityTypeBuilder<MemberPlan> builder)
    {
        builder.ToTable("MemberPlans", t => t.HasCheckConstraint("CK_MemberPlans_EndDate", "[EndDate] >= [StartDate]"));

        // Membership start = insertion date
        builder.Property(mp => mp.StartDate).HasDefaultValueSql("GETDATE()");
        builder.HasIndex(mp => new { mp.MemberId, mp.EndDate });
    }
}
