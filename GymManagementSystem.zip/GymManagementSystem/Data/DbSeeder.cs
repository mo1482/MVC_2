using GymManagementSystem.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace GymManagementSystem.Data;

public static class DbSeeder
{
    public const string AdminEmail = "admin@gym.com";
    public const string AdminPassword = "Admin@123";

    public static async Task SeedAsync(IServiceProvider services)
    {
        var db = services.GetRequiredService<AppDbContext>();

        // Use migrations when they exist, otherwise create the schema directly.
        if (db.Database.GetMigrations().Any())
            await db.Database.MigrateAsync();
        else
            await db.Database.EnsureCreatedAsync();

        // Plans have no "Create" screen in the spec (view / update / deactivate only), so they are seeded.
        if (!await db.Plans.AnyAsync())
        {
            db.Plans.AddRange(
                new Plan { Name = "Basic Plan", Description = "Gym floor access during standard hours for one month.", DurationDays = 30, Price = 300, IsActive = true },
                new Plan { Name = "Standard Plan", Description = "Gym floor access plus group classes for three months.", DurationDays = 90, Price = 800, IsActive = true },
                new Plan { Name = "Premium Plan", Description = "Full access, group classes and 2 personal training sessions per month for six months.", DurationDays = 180, Price = 1400, IsActive = true },
                new Plan { Name = "VIP Annual Plan", Description = "Unlimited access, personal training and nutrition consultation for a full year.", DurationDays = 365, Price = 2400, IsActive = true });
            await db.SaveChangesAsync();
        }

        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
        if (await userManager.FindByEmailAsync(AdminEmail) is null)
        {
            var admin = new ApplicationUser
            {
                UserName = AdminEmail,
                Email = AdminEmail,
                FullName = "Gym Administrator",
                EmailConfirmed = true
            };
            await userManager.CreateAsync(admin, AdminPassword);
        }
    }
}
