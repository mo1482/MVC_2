using AutoMapper;
using GymManagementSystem.Models;
using GymManagementSystem.ViewModels;

namespace GymManagementSystem.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        // ---------- Member ----------
        CreateMap<Member, MemberViewModel>()
            .ForMember(d => d.ActivePlan, o => o.MapFrom(s =>
                s.MemberPlans.Where(mp => mp.EndDate > DateTime.Now).Select(mp => mp.Plan.Name).FirstOrDefault()));

        CreateMap<Member, MemberDetailsViewModel>()
            .ForMember(d => d.Address, o => o.MapFrom(s => s.Address.Full))
            .ForMember(d => d.ActivePlan, o => o.MapFrom(s =>
                s.MemberPlans.Where(mp => mp.EndDate > DateTime.Now).Select(mp => mp.Plan.Name).FirstOrDefault()))
            .ForMember(d => d.Memberships, o => o.MapFrom(s => s.MemberPlans.OrderByDescending(mp => mp.StartDate)));

        CreateMap<Member, MemberFormViewModel>()
            .ForMember(d => d.BuildingNumber, o => o.MapFrom(s => s.Address.BuildingNumber))
            .ForMember(d => d.Street, o => o.MapFrom(s => s.Address.Street))
            .ForMember(d => d.City, o => o.MapFrom(s => s.Address.City))
            .ForMember(d => d.CurrentPhoto, o => o.MapFrom(s => s.Photo))
            .ForMember(d => d.PhotoFile, o => o.Ignore())
            .ForMember(d => d.HeightCm, o => o.MapFrom(s => s.HealthRecord.HeightCm))
            .ForMember(d => d.WeightKg, o => o.MapFrom(s => s.HealthRecord.WeightKg))
            .ForMember(d => d.BloodType, o => o.MapFrom(s => s.HealthRecord.BloodType))
            .ForMember(d => d.Note, o => o.MapFrom(s => s.HealthRecord.Note));

        CreateMap<MemberFormViewModel, Member>()
            .ForMember(d => d.Id, o => o.Ignore())
            .ForMember(d => d.JoinDate, o => o.Ignore())
            .ForMember(d => d.Photo, o => o.Ignore())
            .ForMember(d => d.Address, o => o.Ignore())        // set manually by the service (owned type)
            .ForMember(d => d.HealthRecord, o => o.Ignore())
            .ForMember(d => d.MemberPlans, o => o.Ignore());

        CreateMap<MemberFormViewModel, HealthRecord>()
            .ForMember(d => d.Id, o => o.Ignore())
            .ForMember(d => d.Member, o => o.Ignore());

        // ---------- Trainer ----------
        CreateMap<Trainer, TrainerViewModel>()
            .ForMember(d => d.SessionsCount, o => o.MapFrom(s => s.Sessions.Count));

        CreateMap<Trainer, TrainerDetailsViewModel>()
            .ForMember(d => d.Address, o => o.MapFrom(s => s.Address.Full))
            .ForMember(d => d.SessionsCount, o => o.MapFrom(s => s.Sessions.Count))
            .ForMember(d => d.FutureSessionsCount, o => o.MapFrom(s => s.Sessions.Count(x => x.StartDate > DateTime.Now)))
            .ForMember(d => d.UpcomingSessions, o => o.MapFrom(s =>
                s.Sessions.Where(x => x.StartDate > DateTime.Now).OrderBy(x => x.StartDate)));

        CreateMap<Trainer, TrainerFormViewModel>()
            .ForMember(d => d.BuildingNumber, o => o.MapFrom(s => s.Address.BuildingNumber))
            .ForMember(d => d.Street, o => o.MapFrom(s => s.Address.Street))
            .ForMember(d => d.City, o => o.MapFrom(s => s.Address.City));

        CreateMap<TrainerFormViewModel, Trainer>()
            .ForMember(d => d.Id, o => o.Ignore())
            .ForMember(d => d.HireDate, o => o.Ignore())
            .ForMember(d => d.Address, o => o.Ignore())
            .ForMember(d => d.Sessions, o => o.Ignore());

        // ---------- Plan ----------
        CreateMap<Plan, PlanViewModel>()
            .ForMember(d => d.ActiveMembers, o => o.MapFrom(s => s.MemberPlans.Count(mp => mp.EndDate > DateTime.Now)));

        CreateMap<Plan, PlanFormViewModel>()
            .ForMember(d => d.ActiveMembers, o => o.MapFrom(s => s.MemberPlans.Count(mp => mp.EndDate > DateTime.Now)));

        CreateMap<PlanFormViewModel, Plan>()
            .ForMember(d => d.Id, o => o.Ignore())
            .ForMember(d => d.IsActive, o => o.Ignore())
            .ForMember(d => d.MemberPlans, o => o.Ignore());

        // ---------- Session ----------
        CreateMap<Session, SessionViewModel>()
            .ForMember(d => d.TrainerName, o => o.MapFrom(s => s.Trainer.Name))
            .ForMember(d => d.TrainerSpeciality, o => o.MapFrom(s => s.Trainer.Speciality));

        CreateMap<Session, SessionFormViewModel>()
            .ForMember(d => d.Trainers, o => o.Ignore());

        CreateMap<SessionFormViewModel, Session>()
            .ForMember(d => d.Id, o => o.Ignore())
            .ForMember(d => d.Trainer, o => o.Ignore());

        // ---------- Membership ----------
        CreateMap<MemberPlan, MembershipViewModel>()
            .ForMember(d => d.MemberName, o => o.MapFrom(s => s.Member.Name))
            .ForMember(d => d.PlanName, o => o.MapFrom(s => s.Plan.Name));
    }
}
