# Gym Management System (ASP.NET Core MVC)

ASP.NET Core 8 MVC · Entity Framework Core · SQL Server · Razor + Bootstrap 5 · AutoMapper · ASP.NET Core Identity

## Run

1. Install the **.NET 8 SDK** and have **SQL Server** (or LocalDB / Express) available.
2. Edit `ConnectionStrings:DefaultConnection` in `appsettings.json` if your server is not `.`
   (e.g. `Server=(localdb)\\MSSQLLocalDB;...` or `Server=.\\SQLEXPRESS;...`).
3. From this folder:
   ```
   dotnet restore
   dotnet run
   ```
   The database is created automatically on first run and seeded with 4 plans and an admin user.
4. Login: **admin@gym.com** / **Admin@123**

### Using EF migrations (optional, recommended for the course)
```
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate
dotnet ef database update
```
When migrations exist the app applies them on startup; before that it uses `EnsureCreated`.

## Project structure
```
Controllers/   Home, Dashboard, Account, Member, Trainer, Session, Plan, MemberPlan
Models/        Member, Trainer, Plan, Session, MemberPlan, HealthRecord, Address (owned), enums, ApplicationUser
Data/          AppDbContext, Configurations/ (Fluent API), DbSeeder
Services/      Business rules (one service per area) + PhotoService
ViewModels/    Form / list / details models with validation
Mapping/       AutoMapper profile (ViewModels <-> Entities)
Views/         Razor views + partials
```

## Requirement coverage

| Spec item | Where |
|---|---|
| Member / Trainer / Session full CRUD | `Member|Trainer|SessionController` + services |
| Plans: view, update, deactivate (soft delete) | `PlanController` (`Index`, `Details`, `Edit`, `Activate`), `PlanService` |
| Assign plans to members; cancel | `MemberPlanController`, `MembershipService` |
| Dashboard analytics | `DashboardController`, `DashboardService` (counts, revenue, charts, expiring memberships, next sessions) |
| Login / Sign out | `AccountController` + Identity; all pages require login except Home and Login |
| Address (Building #, Street, City) | `Address` owned type, columns `BuildingNumber`, `Street`, `City` |
| Unique + valid email/phone, Egyptian phone `(010|011|012|015)XXXXXXXX` | VM regex + service checks + unique indexes + SQL CHECK |
| Join date / hire date / membership start set automatically | Set in services + `HasDefaultValueSql("GETDATE()")` |
| Trainer with future sessions cannot be deleted | `TrainerService.DeleteAsync` |
| Trainer must have one specialty | Required `Speciality` enum |
| Session capacity 1-25 (DB constraint) | `CK_Sessions_Capacity` |
| Session end date after start date | VM validation + service + `CK_Sessions_EndDate` |
| Plan duration 1-365 | VM + `CK_Plans_DurationDays` |
| Cannot update/deactivate plans with active memberships | `PlanService` |
| One active membership per member | `MembershipService.CreateAsync` |
| Only active plans can be assigned | `MembershipService.CreateAsync` + filtered dropdown |
| Membership EndDate = Start + plan duration | `MembershipService.CreateAsync` |
| Status computed ("Active" if EndDate > Now else "Expired") | `MemberPlan.Status` (not mapped) |
| Name varchar(50), Email varchar(100), Phone varchar(11) | `*Configuration.cs` |

## Assumptions (not explicit in the spec)
- `MemberController.HealthRecordDetails` exists in the spec but no HealthRecord entity does, so a 1:1 `HealthRecord`
  (height, weight, blood type, notes) was added and is captured in the member form.
- The session form mentions a "category" dropdown, so `Session.Category` (enum) was added.
- Plans have no Create screen in the spec, so 4 plans are seeded.
- Membership "Cancel" sets `EndDate` to now, so the computed status becomes "Expired" and history is kept.
- A member with an active membership cannot be deleted (cancel it first).
- Page styling uses Bootstrap/Chart.js/jQuery validation from CDNs (internet needed in the browser).
