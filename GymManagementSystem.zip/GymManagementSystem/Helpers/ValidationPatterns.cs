namespace GymManagementSystem.Helpers;

public static class ValidationPatterns
{
    /// <summary>Egyptian mobile: (010|011|012|015) followed by 8 digits.</summary>
    public const string EgyptianPhone = @"^(010|011|012|015)\d{8}$";
    public const string EgyptianPhoneMessage = "Phone must be a valid Egyptian number: (010|011|012|015) followed by 8 digits.";
    public const string BloodType = @"^(A|B|AB|O)[+-]$";

    public static readonly string[] BloodTypes = { "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-" };
}
