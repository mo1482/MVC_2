using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Helpers;

public class PastDateAttribute : ValidationAttribute
{
    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value is DateTime d && (d.Date >= DateTime.Today || d.Year < 1900))
            return new ValidationResult(ErrorMessage ?? "Date of birth must be a valid date in the past.");
        return ValidationResult.Success;
    }
}
